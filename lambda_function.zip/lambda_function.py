import boto3
from botocore.exceptions import NoCredentialsError
import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

bucket_name = 'your-bucket-name'
s3 = boto3.client('s3')

path = 'images'
images = []
classNames = []
encodeListKnown = []


def encode_images():
    global encodeListKnown, classNames, images
    encodeListKnown = []
    images = []
    classNames = []

    response = s3.list_objects(Bucket=bucket_name, Prefix=path + '/')
    objects = response.get('Contents', [])
    for obj in objects:
        file_key = obj['Key']
        if file_key.endswith('.jpg') or file_key.endswith('.jpeg') or file_key.endswith('.png'):
            obj_data = s3.get_object(Bucket=bucket_name, Key=file_key)
            img_data = obj_data['Body'].read()

            np_image = np.frombuffer(img_data, np.uint8)
            img = cv2.imdecode(np_image, cv2.IMREAD_COLOR)
            images.append(img)
            classNames.append(os.path.splitext(os.path.basename(file_key))[0])

    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)[0]
        encodeListKnown.append(encode)
    print("encoding comp")


encode_images()
print(len(encodeListKnown))


@app.route("/predict", methods=["POST", "GET"])
def predict():
    if request.method == "GET":
        return jsonify({"method": "GET"})

    try:
        print(len(encodeListKnown))
        image = request.files['image']
        np_image = np.frombuffer(image.read(), np.uint8)
        img = cv2.imdecode(np_image, cv2.IMREAD_COLOR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        facesCurFrame = face_recognition.face_locations(img)
        encodesCurFrame = face_recognition.face_encodings(img, facesCurFrame)

        for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
            matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
            faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)

            matchIndex = np.argmin(faceDis)

            if matches[matchIndex]:
                name = classNames[matchIndex].upper()
                response = jsonify({'id': name})
                print(name)
                return response
        response = jsonify({'error': "Image not recognized"})
        return response

    except Exception as e:
        return jsonify({'error': str(e)})


@app.route("/add", methods=["POST"])
def add():
    try:
        id = request.form.get('id')
        if id in classNames:
            raise ValueError('Image with the same ID number already exists')

        image = request.files['image']
        np_image = np.frombuffer(image.read(), np.uint8)
        img = cv2.imdecode(np_image, cv2.IMREAD_COLOR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        tid = str(id)
        file_name = f'{path}/{tid}.jpg'

        success = upload_to_s3(img, file_name)
        if not success:
            return jsonify({'error': 'Failed to upload image to S3'})

        classNames.append(tid)
        encode_images()
        print("encoding comp for new image")
        print(len(encodeListKnown))
        return jsonify({'status': 'success'})

    except Exception as e:
        return jsonify({"Error": str(e)})


@app.route("/edit", methods=["POST"])
def edit():
    global encodeListKnown
    try:
        image = request.files['image']
        id = request.form.get('id')
        tid = str(id)

        if tid not in classNames:
            return jsonify({'error': f"Employee with ID {id} does not exist"})

        # Delete the old image file
        file_name = f'{path}/{tid}.jpg'
        response = s3.delete_object(Bucket=bucket_name, Key=file_name)
        if response['ResponseMetadata']['HTTPStatusCode'] != 204:
            return jsonify({'error': 'Failed to delete old image from S3'})

        classNames.remove(tid)
        encodeListKnown = []

        # Save the new image file
        np_image = np.frombuffer(image.read(), np.uint8)
        img = cv2.imdecode(np_image, cv2.IMREAD_COLOR)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

        success = upload_to_s3(img, file_name)
        if not success:
            return jsonify({'error': 'Failed to upload new image to S3'})

        # Re-encode all the images
        encode_images()
        print("encoding comp for new image")
        return jsonify({'status': 'success'})

    except Exception as e:
        return jsonify({"Error": str(e)})


def upload_to_s3(image, filename):
    try:
        _, img_encoded = cv2.imencode('.jpg', image)
        response = s3.put_object(Body=img_encoded.tobytes(), Bucket=bucket_name, Key=filename)
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            return True
        else:
            return False
    except NoCredentialsError:
        return False


if __name__ == '__main__':
    app.run()


def lambda_handler(event, context):
    return app
